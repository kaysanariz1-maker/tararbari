TEAM TARARBARI - LOCKED STATIC PRODUCTION COPY

This package is a public-only copy of the supplied current website.
Removed from deployment:
- /admin and all admin login/user management
- editable JSON database/data files
- PHP CMS source and save/upload handlers
- server-check/setup files

Protection applied by install-locked.sh:
- root:root ownership
- directories 0555
- files 0444
- chattr +i on files when supported
- directory listing disabled
- sensitive/source extensions denied by Apache
- SHA256SUMS.txt integrity manifest

IMPORTANT LIMITATION:
Browser-delivered HTML/CSS/JavaScript cannot be truly encrypted while remaining usable by browsers. A visitor can always inspect downloaded frontend code. This build removes the CMS/source data and makes server files read-only/immutable, which is much stronger for deployment protection. A server root user can still deliberately remove the immutable flag and replace files.

Keep your original CMS ZIP offline/private as the editable master source.
