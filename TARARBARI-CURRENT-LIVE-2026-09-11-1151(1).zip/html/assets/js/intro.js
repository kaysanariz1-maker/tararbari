(()=>{
  const root=document.getElementById('tb-intro');
  if(!root)return;
  let cfg={};
  try{cfg=JSON.parse(document.getElementById('tb-intro-config')?.textContent||'{}')}catch(e){}
  const shouldPlay=window.__TB_INTRO_SHOULD_PLAY!==false;
  const html=document.documentElement;
  const cleanupNow=()=>{html.classList.remove('intro-will-play');root.remove();};
  if(!shouldPlay){cleanupNow();return;}

  const cssVars={
    '--intro-primary':cfg.primary||'#22d3ee','--intro-secondary':cfg.secondary||'#22c55e','--intro-accent':cfg.accent||'#60a5fa','--intro-text':cfg.text_color||'#fff','--intro-bg-start':cfg.bg_start||'#08152f','--intro-bg-end':cfg.bg_end||'#172554','--intro-progress-start':cfg.progress_start||'#3b82f6','--intro-progress-end':cfg.progress_end||'#22d3ee','--intro-fade':`${Math.max(.2,parseFloat(cfg.fade_duration)||1)}s`
  };
  Object.entries(cssVars).forEach(([k,v])=>root.style.setProperty(k,v));
  root.classList.add('is-active');

  const stars=root.querySelector('.tb-intro-stars');
  if(stars){
    const density=Math.max(40,Math.min(600,parseInt(cfg.star_density,10)||260));
    const movement=Math.max(1,Math.min(10,parseFloat(cfg.star_speed)||8));
    const twinkle=Math.max(1,Math.min(10,parseFloat(cfg.star_twinkle_speed)||8));
    const maxSize=Math.max(1,Math.min(5,parseFloat(cfg.star_size)||3));
    const baseTravel=Math.max(2.2,17-(movement*1.45));
    const baseTwinkle=Math.max(.38,3.45-(twinkle*.30));
    const frag=document.createDocumentFragment();

    for(let i=0;i<density;i++){
      const s=document.createElement('i');
      const size=.65+Math.random()*Math.max(.35,maxSize-.65);
      const travel=baseTravel*(.68+Math.random()*.72);
      const tw=baseTwinkle*(.65+Math.random()*.90);
      s.style.left=(-8+Math.random()*116)+'%';
      s.style.top=(Math.random()*100)+'%';
      s.style.width=size+'px';
      s.style.height=size+'px';
      s.style.setProperty('--travel',travel+'s');
      s.style.setProperty('--travel-delay',(-Math.random()*travel)+'s');
      s.style.setProperty('--d',tw+'s');
      s.style.setProperty('--delay',(-Math.random()*tw)+'s');
      s.style.setProperty('--star-drift',((-42+Math.random()*84).toFixed(1))+'px');
      s.style.opacity=(.45+Math.random()*.55).toFixed(2);
      if(Math.random()>.80)s.classList.add('bright');
      frag.appendChild(s);
    }
    stars.appendChild(frag);
  }

  const skip=root.querySelector('#tb-intro-skip');
  if(!cfg.skip_enabled&&skip)skip.hidden=true;
  const soundBtn=root.querySelector('#tb-intro-sound');
  const audio=root.querySelector('#tb-intro-audio');
  const fullVideo=root.querySelector('#tb-intro-full-video');
  const hasSound=!!cfg.sound_enabled&&(!!audio||!!fullVideo);
  if(soundBtn)soundBtn.hidden=!hasSound;
  /* TEAM TARARBARI DEFAULT UNMUTED AUTOPLAY V1 */
  const preferredVolume=Math.max(0,Math.min(1,parseFloat(cfg.sound_volume)||0.70));
  let soundOn=false;

  function updateSoundButton(){
    if(soundBtn)soundBtn.textContent=soundOn?'🔊':'🔇';
  }

  async function tryStartAudioUnmuted(){
    if(!audio||!cfg.sound_enabled)return false;

    audio.volume=preferredVolume;
    audio.muted=false;
    audio.defaultMuted=false;
    if(audio.hasAttribute('muted'))audio.removeAttribute('muted');

    try{
      await audio.play();
      soundOn=true;
      updateSoundButton();
      return true;
    }catch(e){
      // Browser blocked audible autoplay. Keep the intro running,
      // then automatically unlock sound on the visitor's first gesture.
      audio.muted=true;
      audio.defaultMuted=true;
      try{await audio.play();}catch(ignore){}
      soundOn=false;
      updateSoundButton();
      return false;
    }
  }

  async function toggleSound(){
    if(soundOn){
      soundOn=false;
      if(audio){audio.muted=true;}
      if(fullVideo)fullVideo.muted=true;
      updateSoundButton();
      return;
    }

    let started=false;
    if(audio){
      audio.volume=preferredVolume;
      audio.muted=false;
      try{await audio.play();started=true;}catch(e){audio.muted=true;}
    }
    if(fullVideo){
      fullVideo.volume=preferredVolume;
      fullVideo.muted=false;
      if(!audio)started=true;
    }
    soundOn=started;
    updateSoundButton();
  }
  updateSoundButton();
  soundBtn?.addEventListener('click',toggleSound);

  /* TEAM TARARBARI AUTOPLAY-FIRST SILENT-UNLOCK V2 */
  let soundGestureUnlocked=false;

  async function unlockSoundOnFirstGesture(){
    if(soundGestureUnlocked||!audio||!cfg.sound_enabled)return;

    try{
      audio.muted=false;
      audio.defaultMuted=false;
      audio.volume=preferredVolume;
      if(audio.hasAttribute('muted'))audio.removeAttribute('muted');

      if(audio.paused){
        await audio.play();
      }

      soundGestureUnlocked=true;
      soundOn=true;
      updateSoundButton();
      removeSoundUnlockListeners();
    }catch(e){
      // Leave the normal sound button available if the browser still refuses.
    }
  }

  function removeSoundUnlockListeners(){
    root.removeEventListener('pointerdown',unlockSoundOnFirstGesture,true);
    root.removeEventListener('touchstart',unlockSoundOnFirstGesture,true);
    root.removeEventListener('click',unlockSoundOnFirstGesture,true);
    root.removeEventListener('keydown',unlockSoundOnFirstGesture,true);
  }

  root.addEventListener('pointerdown',unlockSoundOnFirstGesture,true);
  root.addEventListener('touchstart',unlockSoundOnFirstGesture,true);
  root.addEventListener('click',unlockSoundOnFirstGesture,true);
  root.addEventListener('keydown',unlockSoundOnFirstGesture,true);

  function markSeen(){
    const k='tb_intro_seen';
    try{
      if(cfg.frequency==='session')sessionStorage.setItem(k,'1');
      else if(cfg.frequency==='day')localStorage.setItem(k,new Date().toISOString().slice(0,10));
    }catch(e){}
  }
  let finished=false;
  function finish(delay=350){
    if(finished)return;finished=true;markSeen();
    if(audio)audio.pause();
    setTimeout(()=>{
      root.classList.add('is-leaving');
      setTimeout(cleanupNow,(Math.max(.2,parseFloat(cfg.fade_duration)||1)*1000)+120);
    },delay);
  }
  skip?.addEventListener('click',()=>finish(0));

  const mode=(cfg.mode==='video'&&fullVideo)?'video':'builtin';
  root.classList.toggle('mode-video',mode==='video');
  root.classList.toggle('mode-builtin',mode==='builtin');

  // Safety escape: never let an intro trap a visitor.
  const safety=setTimeout(()=>finish(0),45000);
  const originalFinish=finish;

  if(mode==='video'){
    fullVideo.currentTime=0;
    fullVideo.volume=preferredVolume;
    fullVideo.muted=!cfg.sound_enabled;
    const onEnd=()=>{
      root.classList.add('video-complete');
      setTimeout(()=>finish(0),900);
    };
    fullVideo.addEventListener('ended',onEnd,{once:true});
    fullVideo.addEventListener('error',()=>{root.classList.remove('mode-video');root.classList.add('mode-builtin');tryStartAudioUnmuted();runBuiltin();},{once:true});

    // Prefer unmuted video autoplay. If the browser blocks it, retry muted.
    const play=fullVideo.play();
    if(play&&play.then){
      play.then(()=>{
        soundOn=!!cfg.sound_enabled&&!fullVideo.muted;
        updateSoundButton();
      }).catch(()=>{
        fullVideo.muted=true;
        soundOn=false;
        updateSoundButton();
        fullVideo.play().catch(()=>{
          root.classList.remove('mode-video');
          root.classList.add('mode-builtin');
          tryStartAudioUnmuted();
          runBuiltin();
        });
      });
    }
    return;
  }

  // Built-in animation: try to start the uploaded music UNMUTED first.
  // Chrome/Safari may still block this until the visitor interacts.
  tryStartAudioUnmuted();
  runBuiltin();

  function runBuiltin(){
    const duration=Math.max(3,Math.min(30,parseFloat(cfg.duration)||8))*1000;
    const reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const actualDuration=reduced?Math.min(duration,2200):duration;
    const start=performance.now();
    const fill=root.querySelector('#tb-intro-progress-fill');
    const percent=root.querySelector('#tb-intro-percent');
    const rocket=root.querySelector('#tb-intro-rocket');
    const target=root.querySelector('#tb-intro-target');
    const complete=root.querySelector('#tb-intro-complete');
    function frame(now){
      if(finished)return;
      const p=Math.min(1,(now-start)/actualDuration);
      const eased=p<.5?2*p*p:1-Math.pow(-2*p+2,2)/2;
      if(fill)fill.style.width=(p*100).toFixed(1)+'%';
      if(percent)percent.textContent=Math.round(p*100)+'%';
      if(rocket){
        const x=14+eased*68;
        const y=50-Math.sin(eased*Math.PI)*23-(eased*7);
        const r=-7+Math.sin(eased*Math.PI)*8;
        rocket.style.left=x+'%';rocket.style.top=y+'%';rocket.style.transform=`translate(-50%,-50%) rotate(${r}deg) scale(${1-eased*.08})`;
      }
      if(p>.82)target?.classList.add('approaching');
      if(p>.96){target?.classList.add('landed');root.classList.add('mission-complete');complete?.classList.add('show');}
      if(p<1)requestAnimationFrame(frame);else setTimeout(()=>finish(0),850);
    }
    requestAnimationFrame(frame);
  }
})();
