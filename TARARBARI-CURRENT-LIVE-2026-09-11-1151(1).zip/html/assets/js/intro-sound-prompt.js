/* Team TararBari Intro Sound Prompt */
(function(){
  function init(){
    const root=document.getElementById('tb-intro');
    const prompt=document.getElementById('tb-intro-sound-prompt');
    const btn=document.getElementById('tb-intro-sound-start');
    if(!root || !prompt || !btn) return;

    const configEl=document.getElementById('tb-intro-config');
    let cfg={};
    try{ cfg=JSON.parse(configEl ? configEl.textContent : '{}') || {}; }catch(e){}

    if(!cfg.sound_prompt_enabled || !cfg.sound_enabled){
      prompt.remove();
      return;
    }

    const vol=Math.max(0,Math.min(1,Number(cfg.sound_prompt_volume ?? 80)/100));

    async function startWithSound(){
      let played=false;

      const audio=document.getElementById('tb-intro-audio');
      if(audio){
        try{
          audio.muted=false;
          audio.defaultMuted=false;
          audio.volume=vol;
          audio.removeAttribute('muted');
          await audio.play();
          played=true;
        }catch(e){}
      }

      const fullVideo=document.getElementById('tb-intro-full-video');
      if(fullVideo){
        try{
          fullVideo.muted=false;
          fullVideo.defaultMuted=false;
          fullVideo.volume=vol;
          fullVideo.removeAttribute('muted');
          if(fullVideo.paused) await fullVideo.play();
          played=true;
        }catch(e){}
      }

      const soundBtn=document.getElementById('tb-intro-sound');
      if(soundBtn){
        soundBtn.textContent=played ? '🔊' : '🔇';
        soundBtn.setAttribute('aria-pressed',played?'true':'false');
      }

      prompt.classList.add('is-closing');
      setTimeout(()=>prompt.remove(),220);

      try{
        root.dispatchEvent(new CustomEvent('tb:intro-sound-started',{detail:{played}}));
      }catch(e){}
    }

    btn.addEventListener('click',startWithSound,{once:true});
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init);
  else init();
})();
